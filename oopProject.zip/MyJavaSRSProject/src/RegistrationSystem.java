// STUDENT REGISTRATION SYSTEM PROJECT WITH JAVA.
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

// class for User
class User
{
    private final String username;
    private final String password;
    public User(String username, String password)

    {
        this.username = username;
        this.password = password;
    }
    public boolean authenticate(String username, String password)
    {
        return this.username.equals(username) && this.password.equals(password);
    }
}
//  class Student inherits from User
class Student extends User
{
    private String name,department,sex;
    private int id,year,semester;
    private ArrayList<Course> courses;
    public Student(String username, String password, String name, String department, int id, String sex, int year, int semester)
    {
        super(username, password);
        this.name = name;
        this.department = department;
        this.id = id;
        this.sex = sex;
        this.year = year;
        this.semester = semester;
        this.courses = new ArrayList<>();
    }
    // Overloaded constructor for creating a Student
    public Student(String username, String password)
    {
        super(username, password);
    }
    public void registerCourse(Course course)
    {
        courses.add(course);
    }
    public void viewProfile()
    {
        System.out.println("Student Name: " + name);
        System.out.println("Student Department: " + department);
        System.out.println("Student ID: " + id);
        System.out.println("Sex: " + sex);
        System.out.println("Education Year: " + year);
        System.out.println("Semester: " + semester);
        System.out.println("Registered Courses:");

        for (Course course : courses)
        {
            System.out.println(course.getCourseTitle() + "---------" + course.getCourseCode());
        }
    }
}
// Course class
class Course
{
    private final String courseTitle;
    private final String courseCode;
    private final int creditHours;

    public Course(String courseTitle, String courseCode, int creditHours)
    {
        this.courseTitle = courseTitle;
        this.courseCode = courseCode;
        this.creditHours = creditHours;
    }
    public String getCourseTitle()

    {
        return courseTitle;
    }
    public String getCourseCode()
    {
        return courseCode;
    }

    public int getCreditHours()
    {
        return creditHours;
    }
}

  public class RegistrationSystem
  {
    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);
        Student student = null; // Initialize student variable

        System.out.println("Welcome to the Student Registration System!");
        System.out.println("##########################################");
        int loginChoice;
        while (true)
        {
            System.out.println("1. LOGIN");
            System.out.println("2. EXIT");
            System.out.println("3. ABOUT");

            System.out.print("\nEnter your choice: ");
            loginChoice = scanner.nextInt();
            scanner.nextLine();
            //login part
            if (loginChoice == 1)
            {
                System.out.print("Enter username: ");
                String loginUsername = scanner.nextLine();
                System.out.print("Enter  password: ");
                String loginPassword = scanner.nextLine();

                int choice;
                while (true)
                {
                    System.out.println("\n1.REGISTER");
                    System.out.println("2. PROFILE");
                    System.out.println("3. LOGOUT");
                    System.out.println("4. EXIT");
                    System.out.println("5. HELP");
                    System.out.print("Enter  choice: ");
                    choice = scanner.nextInt();
                    scanner.nextLine(); // Consume the newline character

                    if (choice == 1)
                    {
                        String valid;
                        // Capture student information
                        try
                        {
                            System.out.print("Enter Name: ");
                            String name = scanner.nextLine();
                                // Validate name (only characters)
                            if (name.matches("[a-zA-Z]+"))
                                {
                                    // valid name
                                }
                                else

                            {
                                throw new InputMismatchException("Invalid name.");
                            }

                             System.out.print("Enter your Sex: ");
                             String sex = scanner.nextLine();
                             if (sex.equalsIgnoreCase("male") || sex.equalsIgnoreCase("female"))
                             {
                                // Valid sex
                             }
                             else
                            {
                                throw new InputMismatchException("Invalid sex.");
                            }
                            System.out.println("Enter ID");
                            int  id =scanner.nextInt();

                            scanner.nextLine(); // Consume the newline character

                            System.out.print("Enter Department: ");
                            String department = scanner.nextLine();

                            System.out.print("Enter  Education year: ");
                            int year = scanner.nextInt();

                            System.out.print("Enter Education Semester: ");
                            int semester = scanner.nextInt();
                            scanner.nextLine(); // Consume the newline character

                            // Create a new student with detailed information
                            student = new Student(loginUsername, loginPassword, name, department, id, sex, year, semester);

                            // Capture course information
                            System.out.println("Enter the number of courses: ");
                            int numCourses = scanner.nextInt();
                            scanner.nextLine();

                            Course[] courses = new Course[numCourses];

                            // Register each course
                            for (int i = 0; i < numCourses; i++)
                            {
                                System.out.println("Enter details for Course " + (i + 1) + ":");
                                System.out.print("Course Title: ");
                                String courseTitle = scanner.nextLine();

                                System.out.print("Course Code: ");
                                String courseCode = scanner.nextLine();

                                System.out.print("Credit Hour: ");
                                int creditHours = scanner.nextInt();
                                scanner.nextLine(); // Consume the newline character

                                // Validate course details
                                if (!courseCode.matches("[a-zA-Z0-9]+"))
                                {

                                    throw new InputMismatchException("Invalid course code.");
                                }

                            Course course = new Course(courseTitle, courseCode, creditHours);
                            student.registerCourse(course);
                            }
                        }
                        catch (InputMismatchException e)
                        {
                            System.out.println("Input error: " + e.getMessage());
                            scanner.nextLine(); // Consume the newline character
                        }

                    System.out.println("Course registered successfully!");
                    }
                    else if (choice == 2)
                    {
                        student.viewProfile();
                    }
                    else if (choice == 3)
                    {
                        System.out.println("Logout successful. ");
                        break;
                    }
                    else if (choice == 4)
                    {
                        // Exit from the system
                        System.out.println("Exiting the system. Goodbye!");
                        System.exit(0);
                    }
                    else if (choice == 5)
                    {
                        System.out.println("This is a place where you get some information about the system.");
                        System.out.println("1.for registration\n2.for view your profile after registration. ");
                        System.out.println("3.when you want to logout from system\n4.for exit totally from the system");
                    }
                    else
                    {

                        System.out.println("Invalid choice.");
                    }
                }
            }
            else if (loginChoice == 2)
            {
                // Exit from the system totally
                System.out.println("you are out from the system. Goodbye!");
                System.exit(0);
            }
            else if (loginChoice ==3)
            {
                System.out.println("***** ABOUT *****\n");
                System.out.println("This is  Student Registration System.");
                System.out.println("Using This System Students Can Register For Their Academic Education.");
            }
            else
            {
                // Invalid choice
                System.out.println("Invalid choice.");
            }
        }
    }
}

